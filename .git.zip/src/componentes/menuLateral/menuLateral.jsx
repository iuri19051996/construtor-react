import "./menuLateral.css"

export function Menulateral() {

    return (
      <div className="menu-lateral">
        teste
      </div>
    )
}