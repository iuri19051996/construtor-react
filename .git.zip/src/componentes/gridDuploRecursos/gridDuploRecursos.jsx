import { MenulateralRecursos } from "../menuLateralRecursos/menuLateralRecursos"
import "./gridDuploRecursos.css"

export function Gridduplorecursos() {

    return (
      <div className="grid-duploRecursos">
        <MenulateralRecursos />
        <div className="btn-rotas">
          
        </div>
      </div>
    )
}