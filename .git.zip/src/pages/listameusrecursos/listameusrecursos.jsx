import { Listameusrecursos } from "../../componentes/meusRecursos/meusRecursos";

export function Meusrecursos() {

    return (
      <>
      <Listameusrecursos />
      </>
    )
}