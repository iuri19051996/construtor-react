import { Gridduplorecursos } from "../../componentes/gridDuploRecursos/gridDuploRecursos"
import "./memoria.css"

export function Memoria() {

  return (
      <>
      <Gridduplorecursos />
      </>
    
    )
}