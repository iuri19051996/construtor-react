import { Listatodosrecursos } from "../../componentes/todosRecursos/todosRecursos";

export function Todosrecursos() {

    return (
      <>
      <Listatodosrecursos />
      </>
    )
}