//import "./quiz.css"

import { Gridduplorecursos } from "../../componentes/gridDuploRecursos/gridDuploRecursos";

export function Quiz() {

    return (
      <>
      <Gridduplorecursos />
      </>
    )
}