//import "./home.css"
import { Gridduplo } from "../../componentes/gridDuplo/gridDuplo"

export function Home() {

    return (
    <>
      <Gridduplo />
    </>
    )
}

